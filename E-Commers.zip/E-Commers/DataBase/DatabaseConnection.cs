﻿using E_Commers.Modules;
using Microsoft.EntityFrameworkCore;

namespace E_Commers.DataBase
{
    public class DatabaseConnection: DbContext

    {
        public DatabaseConnection(DbContextOptions<DatabaseConnection> options) : base(options)
        {

        }
        public DbSet<UserDetails> Users { get; set; }
        public DbSet<ProductList> products { get; set; }

        public DbSet<ObjectId> Cart {  get; set; }

    }

}
