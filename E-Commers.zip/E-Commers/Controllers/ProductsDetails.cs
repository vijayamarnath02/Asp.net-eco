﻿using E_Commers.Modules;
using E_Commers.Repositer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace E_Commers.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsDetails : ControllerBase
    {
        private readonly IProductData _data;

        public ProductsDetails(IProductData data)
        {
            _data = data;
        }


        [HttpGet]
        [Route("/getProducts")]
        public IActionResult GetProducts([FromHeader] string token)
        {

            if (!string.IsNullOrWhiteSpace(token))
            {
                try
                {
                    var result = _data.ProductList();
                    return Ok( result);
                }
                catch (Exception ex)
                {
                    return BadRequest($"An error occurred: {ex.Message}");
                }
            }
            else
            {
                return BadRequest("Authentication token is missing or empty.");
            }
        }
        [HttpGet]
        [Route("/filterList")]
        public IActionResult FilterSearch([FromHeader] string token)
        {
            if (!string.IsNullOrWhiteSpace(token))
            {
                var result = _data.FilterList();
                return Ok(result);
            }
            else
            {
                return BadRequest();
            }

        }
        [HttpGet]
        [Route("/filterBrand")]
        public IActionResult FilterBrand([FromHeader] string token)
        {
            try
            {


                if (!string.IsNullOrWhiteSpace(token))
                {


                    var result = _data.FilterBrandList();
                 return Ok(new { success = result });

                }
                else
                {
                    return BadRequest();
                }
            }
            catch(Exception ex)
            {
                return BadRequest(ex);
            }

        }

        [HttpPost]
        [Route("/filter/search")]
        public IActionResult FilterResults([FromHeader] string token, [FromBody] DataSearch pro)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(token))
                {
                    var result = _data.DataSearch(pro);
                    return Ok(result);
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return BadRequest();
            }

        }

        [HttpPost]
        [Route("/filter/view")]
        public IActionResult FindData([FromHeader] string token, [FromBody] ObjectId obj)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(token))
                {
                    var result = _data.ViewData(obj);
                    return Ok(result);
                }
                else
                {
                    return BadRequest("No Token Has Been Send");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        [HttpPost]
        [Route("/filter/addcart")]
        public IActionResult addCart([FromHeader] string token, [FromBody] ObjectId obj)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(token))
                {
                    var result = _data.AddToCart(obj, token);

                    return Ok("SuccessFully Add To Cart");
                }
                else
                {
                    return BadRequest("No Token Has Been Send");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("/filter/cartview")]
        public IActionResult CartView([FromHeader] string token)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(token))
                {
                    var result = _data.CartView(token);

                    return Ok(result);
                }
                else
                {
                    return BadRequest("No Token Has Been Send");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        [HttpPost]
        [Route("/filter/subraction")]
        public IActionResult subRation([FromHeader] string token, [FromBody] ObjectId obj)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(token))
                {
                    var result = _data.Subtract(obj, token);
                    return Ok("SuccessFully lessed ");
                }
                else
                {
                    return BadRequest("No Token Has Been Send");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }

        }
        [HttpGet]
        [Route("/filter/length")]
        public IActionResult Length([FromHeader] string token)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(token))
                {
                    var result = _data.LengthCart(token);
                    return Ok(result);
                }
                else
                {
                    return BadRequest("Sry No Data Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }
        [HttpDelete]
        [Route("/filter/delete")]
        public IActionResult Delete([FromBody] ObjectId id)
        {
            try
            {
             
                    var result = _data.DeleteCartItem(id);
                    return Ok(result);  
                
            
            }
            catch (Exception ex)
            {
                return BadRequest(ex.ToString());
            }
        }
    }
}





