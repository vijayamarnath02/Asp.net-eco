﻿using E_Commers.Modules;
using E_Commers.Repositer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;

namespace E_Commers.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginAndSignup : ControllerBase
    {
        private readonly IUserCreateData _data;


        public LoginAndSignup(IUserCreateData data)
        {
            _data = data;
        }


        [Route("/create")]
        [HttpPost]
        public IActionResult CreateUser1([FromBody] UserDetails user)
        {

            try
            {
                var result = _data.CreateUser(user);
                var response = new { name = result };
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest("please Log in");
            }

        }

        [Route("/login")]
        [HttpPost]
        public IActionResult login(LoginChecker log)
        {
            try
            {
                var result = _data.CheckTheUser(log);
                var response = new { name = result };
                return Ok(response);
            }
            catch
            {
                return BadRequest();
            }
        }


        [Route("/userdetails")]
        [HttpGet]
        public IActionResult UserForm1([FromHeader] string token)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(token))
                {
                    var result=_data.GetUsers(token);
                    return Ok(result);
                }
                else
                {
                    return BadRequest();
                }
            }
            catch
            {
                return BadRequest();
            }
               

        }
    }

}
