﻿using E_Commers.Modules;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Reflection.PortableExecutable;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace E_Commers.Repositer
{
    public class UserCreateData : IUserCreateData
    {
        private readonly string  connectionString = "Server=DESKTOP-EC64EA6;Database=Ecommerce;Encrypt=false;Trusted_Connection=True;";
        public List<UserDetails> GetUsers(string t)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                ;
                connection.Open();
                string query = $@"SELECT * FROM Users WHERE Email = '{t}'";
                Console.WriteLine(query);
                SqlCommand command1 = new SqlCommand(query, connection);
                SqlDataReader reader = command1.ExecuteReader();
                List<UserDetails> user = new List<UserDetails>();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        UserDetails User = new UserDetails();
                        User.Name = reader.GetString(reader.GetOrdinal("name"));
                        User.Email = reader.GetString(reader.GetOrdinal("email"));
                        User.Mobile = reader.GetString(reader.GetOrdinal("mobile"));
                        User.Password = reader.GetString(reader.GetOrdinal("password"));
                        User.DateTime = reader.GetDateTime(reader.GetOrdinal("DateTime"));
                        User.Status = reader.GetInt32(reader.GetOrdinal("status"));
                        user.Add(User);

                    }
                }

                return user;
            }
        }

        string IUserCreateData.CheckTheUser(LoginChecker? login)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {

                    connection.Open();
                    string query1 = $@"SELECT * FROM Users WHERE Email = '{login.Email}'";
                    SqlCommand command1 = new SqlCommand(query1, connection);
                    SqlDataReader reader1 = command1.ExecuteReader();
                    if (reader1.HasRows)
                    {
                        while (reader1.Read())
                        {
                            var Email = reader1.GetString(reader1.GetOrdinal("Email"));
                            var Password = reader1.GetString(reader1.GetOrdinal("Password"));
                            if (Email == null || Password == null)
                            {
                                throw new Exception("Password And Email Must Be Filled");
                            }
                            else if (Email == login.Email)
                            {
                                if (Password == login.Password)
                                {
                                    return login.Email;
                                }
                                else
                                {
                                    throw new Exception("Password Not Match Please Enter the Correctly");

                                }
                            }
                            else if (Email != login.Email)
                            {
                                throw new Exception("Email Not Match Please Enter the Correctly");
                            }

                        }

                        return login.Email;
                    }
                    else
                    {
                        throw new Exception("Email And Password  Not Match Please Enter the Correctly");
                    }
                }
                catch
                {
                    throw new Exception("Email Not Match Please Enter the Correctly");
                }
            }
        }

        string IUserCreateData.CreateUser(UserDetails? user)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if the email already exists
                    string queryCheckEmail = $"SELECT COUNT(*) AS count FROM Users WHERE Email = '{user.Email}'";
                    SqlCommand commandCheckEmail = new SqlCommand(queryCheckEmail, connection);

                    int count = (int)commandCheckEmail.ExecuteScalar();
                    connection.Close();


                    if (count == 0)
                    {
                        connection.Open();
                        string queryInsert = $@"INSERT INTO Users (Name, Email, Password, Mobile, Status)
                                       VALUES ('{user.Name}', '{user.Email}', '{user.Password}', '{user.Mobile}', 1)";
                        SqlCommand commandInsert = new SqlCommand(queryInsert, connection);
                        int rowsAffected = commandInsert.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return user.Email; 
                        }
                        else
                        {
                            throw new Exception("Email already exists");
                        }
                    }
                    else
                    {
                        throw new Exception("Email already exists");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error creating user");
            }
        }

    }
}
