﻿    using E_Commers.Modules;

namespace E_Commers.Repositer
{
    public interface IProductData
    {
        List<ProductList> ProductList();
        List<FilterData> FilterList();
        List<FilterBrandData> FilterBrandList();
        List<ProductList> DataSearch(DataSearch data);
        List<ProductList> ViewData(ObjectId id);
        int AddToCart(ObjectId cd, string token);
        List<ProductList> CartView(string token);
        int Subtract(ObjectId id, string token);
        int LengthCart(string token);
        int DeleteCartItem(ObjectId id);

    }
}
