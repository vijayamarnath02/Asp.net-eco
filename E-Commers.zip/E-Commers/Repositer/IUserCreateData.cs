﻿using E_Commers.Modules;

namespace E_Commers.Repositer
{
    public interface IUserCreateData
    {

        string CheckTheUser(LoginChecker? login);
        string CreateUser(UserDetails? user);
        List<UserDetails> GetUsers(string token);

    }
}
