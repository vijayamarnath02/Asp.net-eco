﻿using E_Commers.DataBase;
using E_Commers.Modules;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
namespace E_Commers.Repositer
{
    public class ProductData : IProductData
    {

        private readonly string connectionString = "Server=DESKTOP-EC64EA6;Database=Ecommerce;Encrypt=false;Trusted_Connection=True;";

        public int AddToCart(ObjectId da, string token)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                int count = -1;
                string query1 = "";
                try
                {


                    connection.Open();
                    string query = $"Select count(*) data from Cart where userid={da.Id} And userEmail='{token}';";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();


                    if (reader.Read())
                    {
                        count = Convert.ToInt32(reader["data"]);
                        Console.WriteLine($"Count: {count}");
                        connection.Close();

                    }
                    else
                    {
                        connection.Close();
                        throw new Exception("Sry Data nOt Found");
                    }
                    if (count == 0)
                    {
                        query1 = $@"INSERT INTO Cart (userid,userEmail,Count)VALUES ({da.Id}, '{token}', 1); ";
                    }
                    else
                    {
                        query1 = $@"UPDATE c SET c.Count = c.Count + 1 FROM Cart c WHERE c.userid ={da.Id} And c.userEmail='{token}' ;";
                    }
                    try
                    {
                        connection.Open();
                        Console.WriteLine(query1);
                        SqlCommand command1 = new SqlCommand(query1, connection);
                        SqlDataReader reader1 = command1.ExecuteReader();
                        return 0;
                    }
                    catch
                    {
                        throw new Exception("Sry No Data Added");
                    }
                }
                catch
                {
                    throw new Exception("No data Found");
                }


            }
        }



        public List<ProductList> CartView(string token)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {

                    connection.Open();
                    string query = $@"SELECT * FROM Cart INNER JOIN products ON Cart.userid = products.id where Cart.userEmail ='{token}';";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    List<ProductList> Search = new List<ProductList>();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            ProductList brand = new ProductList();
                            brand.id = reader.GetInt32(reader.GetOrdinal("userid"));
                            brand.Title = reader.GetString(reader.GetOrdinal("title"));
                            brand.Description = reader.GetString(reader.GetOrdinal("description"));
                            brand.Price = reader.GetInt32(reader.GetOrdinal("price"));
                            brand.DiscountPercentage = reader.GetInt32(reader.GetOrdinal("discountPercentage"));
                            brand.Rating = reader.GetInt32(reader.GetOrdinal("rating"));
                            brand.Stock = reader.GetInt32(reader.GetOrdinal("stock"));
                            brand.Brand = reader.GetString(reader.GetOrdinal("brand"));
                            brand.Category = reader.GetString(reader.GetOrdinal("category"));
                            brand.Thumbnail = reader.GetString(reader.GetOrdinal("thumbnail"));
                            brand.Count = reader.GetInt32(reader.GetOrdinal("count"));
                            Search.Add(brand);
                        }

                    }
                    connection.Close();

                    return Search;
                }
                catch
                {
                    throw new Exception("No data Found");
                }
            }
        }

        public List<ProductList> DataSearch(DataSearch data)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {

                    connection.Open();
                    string query = "";
                    if (data.Brand != null && data.Catagery == null)
                    {
                        query = $@"select *  FROM products where brand='{data.Brand}'";
                    }
                    else if (data.Catagery != null && data.Brand == null)
                    {
                        query = $@"select *  FROM products where category='{data.Catagery}'";
                    }
                    else if (data.Catagery != null && data.Brand != null)
                    {
                        query = $@"select *  FROM products WHERE  category ='{data.Catagery}' AND  brand ='{data.Brand}'";
                    }
                    else
                    {
                        query = "select * from products ";
                    }
                    Console.WriteLine(query);
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    List<ProductList> Search = new List<ProductList>();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            ProductList brand = new ProductList();
                            brand.id = reader.GetInt32(reader.GetOrdinal("id"));
                            brand.Title = reader.GetString(reader.GetOrdinal("title"));
                            brand.Description = reader.GetString(reader.GetOrdinal("description"));
                            brand.Price = reader.GetInt32(reader.GetOrdinal("price"));
                            brand.DiscountPercentage = reader.GetInt32(reader.GetOrdinal("discountPercentage"));
                            brand.Rating = reader.GetInt32(reader.GetOrdinal("rating"));
                            brand.Stock = reader.GetInt32(reader.GetOrdinal("stock"));
                            brand.Brand = reader.GetString(reader.GetOrdinal("brand"));
                            brand.Category = reader.GetString(reader.GetOrdinal("category"));
                            brand.Thumbnail = reader.GetString(reader.GetOrdinal("thumbnail"));

                            Search.Add(brand);
                        }


                    }
                    connection.Close();

                    return Search;
                }
                catch (Exception ex)
                {
                    throw new Exception("No data Found");
                }
            }
        }

        public int DeleteCartItem(ObjectId id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {

                    connection.Open();
                    string query = $"DELETE FROM Cart WHERE userId={id.Id}And userEmail='{id.Token}';";
                    Console.WriteLine(query);
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    return 0;
                }
                catch
                {
                    throw new Exception("No Data Has Been Deleted");
                }
            }
        }

        public List<FilterBrandData> FilterBrandList()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {

                    connection.Open();
                    string query = "SELECT DISTINCT brand FROM products;";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    List<FilterBrandData> Brand = new List<FilterBrandData>();

                    if (reader.HasRows)
                    {


                        while (reader.Read())
                        {
                            FilterBrandData brand = new FilterBrandData();
                            brand.Brand = reader.GetString(reader.GetOrdinal("brand"));

                            Brand.Add(brand);
                        }


                    }
                    connection.Close();
                    return Brand;

                }
                catch
                {
                    throw new Exception("No data Found");
                }
            }
        }

        public List<FilterData> FilterList()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                try
                {

                    connection.Open();
                    string query = "SELECT DISTINCT category FROM products;";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    List<FilterData> Category = new List<FilterData>();

                    if (reader.HasRows)
                    {


                        while (reader.Read())
                        {
                            FilterData category = new FilterData();
                            category.Category = reader.GetString(reader.GetOrdinal("category"));

                            Category.Add(category);
                        }


                    }
                    connection.Close();
                    return Category;
                }
                catch
                {
                    throw new Exception("No data Found");
                }
            }
        }

        public int LengthCart(string token)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                int count = -1;
                try
                {

                    connection.Open();
                    string query = $"Select Count(*) count from Cart where userEmail = '{token}'";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            count = reader.GetInt32(reader.GetOrdinal("count"));
                        }
                    }
                    return count;
                }
                catch
                {
                    throw new Exception("No data Found"); ;
                }
            }
        }

        public List<ProductList> ProductList()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {

                    connection.Open();
                    string query = "Select * from products";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    List<ProductList> Products = new List<ProductList>();

                    if (reader.HasRows)
                    {


                        while (reader.Read())
                        {
                            ProductList product = new ProductList();
                            product.id = reader.GetInt32(reader.GetOrdinal("id"));
                            product.Title = reader.GetString(reader.GetOrdinal("title"));
                            product.Description = reader.GetString(reader.GetOrdinal("description"));
                            product.Price = reader.GetInt32(reader.GetOrdinal("price"));
                            product.DiscountPercentage = reader.GetInt32(reader.GetOrdinal("discountPercentage"));
                            product.Rating = reader.GetInt32(reader.GetOrdinal("rating"));
                            product.Stock = reader.GetInt32(reader.GetOrdinal("stock"));
                            product.Brand = reader.GetString(reader.GetOrdinal("brand"));
                            product.Category = reader.GetString(reader.GetOrdinal("category"));
                            product.Thumbnail = reader.GetString(reader.GetOrdinal("thumbnail"));

                            Products.Add(product);
                        }


                    }

                    return Products;
                }
                catch (Exception ex)
                {
                    throw new Exception("No data Found"); ;
                }
            }
        }

        public int Subtract(ObjectId id, string token)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {



                    connection.Open();
                    string query = $@"UPDATE c SET c.Count = c.Count - 1 FROM Cart c WHERE c.userid ={id.Id} And c.userEmail='{token}' ;";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    return 0;
                }
                catch (Exception ex)
                {
                    throw new Exception("No data Found"); ;
                }
            }

        }

        public List<ProductList> ViewData(ObjectId obj)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {

                    connection.Open();

                    string query = $"Select * from products where id={obj.Id}";
                    Console.WriteLine(query);
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    List<ProductList> Products = new List<ProductList>();

                    if (reader.HasRows)
                    {


                        while (reader.Read())
                        {
                            ProductList product = new ProductList();
                            product.id = reader.GetInt32(reader.GetOrdinal("id"));
                            product.Title = reader.GetString(reader.GetOrdinal("title"));
                            product.Description = reader.GetString(reader.GetOrdinal("description"));
                            product.Price = reader.GetInt32(reader.GetOrdinal("price"));
                            product.DiscountPercentage = reader.GetInt32(reader.GetOrdinal("discountPercentage"));
                            product.Rating = reader.GetInt32(reader.GetOrdinal("rating"));
                            product.Stock = reader.GetInt32(reader.GetOrdinal("stock"));
                            product.Brand = reader.GetString(reader.GetOrdinal("brand"));
                            product.Category = reader.GetString(reader.GetOrdinal("category"));
                            product.Thumbnail = reader.GetString(reader.GetOrdinal("thumbnail"));

                            Products.Add(product);
                        }


                    }

                    return Products;

                }
                catch (Exception ex)
                {
                    throw new Exception("No data Found");
                }
            }


        }
    }
}
