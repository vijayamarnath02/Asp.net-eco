﻿namespace E_Commers.Modules
{
    public class DataSearch
    {
        public string? Brand { get; set; }
        public string? Catagery { get; set; }
    }
}
