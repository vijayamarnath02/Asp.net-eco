﻿namespace E_Commers.Modules
{
    public class LoginChecker
    {
        public string Email {  get; set; }
        public string Password { get; set; }
    }
}
