﻿namespace E_Commers.Modules
{
    public class FilterData
    {
        public string? Category { get; set; }
      
    }
}
