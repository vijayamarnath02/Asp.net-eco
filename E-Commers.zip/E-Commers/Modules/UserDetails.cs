﻿namespace E_Commers.Modules
{
    public class UserDetails
    {

        public string Name { get; set; }    
        public string Email { get; set; }   
        public string Password { get; set; }

        public string Mobile { get; set; }

        public DateTime DateTime { get; set; }
        public int Status { get; set; }






    }
}
