﻿namespace E_Commers.Modules
{
    public class ObjectId
    {
        public int Id { get; set; }
        public string ?Token { get; set; }
    }
}
