﻿namespace E_Commers.Modules
{
    public class FilterBrandData
    {
        public string? Brand { get; set; }

    }
}
